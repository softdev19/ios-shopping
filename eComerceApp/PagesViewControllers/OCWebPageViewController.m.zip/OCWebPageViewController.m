//
//  OCWebPageViewController.m
//  eComerceApp
//
//  Created by Tarek Issa on 5/16/14.
//  Copyright (c) 2014 Tvinci. All rights reserved.
//

#import "OCWebPageViewController.h"
#import "JASidePanelController.h"
//#import "OCCartButton.h"
#import "OCLauncherCounterManager.h"
#import "OCCartWebViewController.h"



@interface OCWebPageViewController ()  <UIWebViewDelegate, UIAlertViewDelegate> {
    NSString *initialHtmlStr;
}
@property (strong) NSURL* url;
@property (nonatomic, assign) BOOL isMainPage;
@property (nonatomic, strong) UIWebView *webview;

@end

@implementation OCWebPageViewController


- (void)dealloc
{
    NSLog(@"Deallocated");

    self.webview.delegate = nil;
    [self.webview stopLoading];
    [self.webview removeFromSuperview];
}



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andPageUrl:(NSURL *)pageUrl
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.url = pageUrl;
        [self setup];
        [self loadWebview];
    }
    return self;
}

- (id)initMainPageWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andPageUrl:(NSURL *)pageUrl
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.url = pageUrl;
        self.isMainPage = YES;
        [self setup];
        [self loadWebview];
    }
    return self;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (id)initWithPageUrl:(NSURL *)pageUrl {
    self = [super init];
    if (self) {
        // Custom initialization
        self.url = pageUrl;

        [self setup];
        [self loadWebview];
    }
    return self;

}

- (void)setup {
    self.webview = [[UIWebView alloc] init];
    [self.webview setBackgroundColor:[UIColor clearColor]];
    [self.view addSubview:self.webview];
    self.webview.delegate = self;
}

- (void)loadWebview {
    self.webview.delegate = self;
    if (self.isMainPage) {
        NSURLRequest *req = [NSURLRequest requestWithURL:self.url];
        [NSURLConnection sendAsynchronousRequest:req queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
            initialHtmlStr = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            NSLog(@"Done");
            
            // etc
            if (self.isViewLoaded) {
                [self.webview loadHTMLString:initialHtmlStr baseURL:nil];
            }
        }];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    if (self.isMainPage) {
        if (initialHtmlStr != nil) {
            [self.webview loadHTMLString:initialHtmlStr baseURL:nil];
        }
    }else{
        [[NSNotificationCenter defaultCenter] postNotificationName:OCShowLoad object:nil];
        NSURLRequest *urlRequest = [NSURLRequest requestWithURL:self.url];
        [self.webview loadRequest:urlRequest];
    }
}


-(void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];

    CGRect frame = self.webview.frame;
    frame.origin = CGPointZero;
    frame.size = self.view.frame.size;
    self.webview.frame = frame;
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

//    [[OCPlistParser sharedOCPlistParser] platform];

}

#pragma mark - Navigation Buttons


- (void)fadeOut {
//    [[NSNotificationCenter defaultCenter] postNotificationName:OCShowLoad object:nil];
//    self.webview.hidden = NO;
//    self.webview.alpha = 1.0;
//
//    [UIView animateWithDuration:0.35 delay:0.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
//        self.webview.alpha = 0.0;
//    } completion:^(BOOL finished) {
//        self.webview.hidden = YES;
//    }];
}

- (void)fadeIn {
    [[NSNotificationCenter defaultCenter] postNotificationName:OCHideLoad object:nil];
//    self.webview.alpha = 0.0;
//    self.webview.hidden = NO;
//    [UIView animateWithDuration:0.35 delay:0.0 options:UIViewAnimationOptionCurveEaseIn animations:^{
//        self.webview.alpha = 1.0;
//    } completion:nil];
}

#pragma mark - UIWebViewDelegate

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    
    if (self.DoNotCheckRedirects) {
        return YES;
    }
    
    if ([self handleRequestUrl:[request.URL absoluteString]]) {
        return NO;
    }
    
    
    if (navigationType == UIWebViewNavigationTypeLinkClicked) {
        
        if ([[[request.URL absoluteString] lowercaseString] rangeOfString:@"app=1&"].location != NSNotFound) {
            [[NSNotificationCenter defaultCenter] postNotificationName:OCShowLoad object:nil];
            return YES;
        }
        if ([self samePage:request.URL andSecondUrl:self.url]) {
            [[NSNotificationCenter defaultCenter] postNotificationName:OCShowLoad object:nil];
            return YES;
        }
        if ([[[request.URL absoluteString] lowercaseString] rangeOfString:@"remove/item"].location != NSNotFound) {
            [self fadeOut];
            return YES;
        }
        if ([[[request.URL absoluteString] lowercaseString] rangeOfString:@"cart/delete/"].location != NSNotFound) {
            [self fadeOut];
            return YES;
        }

        NSURL* newUrl = request.URL;
        OCWebPageViewController* webpageViewController = [[OCWebPageViewController alloc] initWithNibName:@"OCWebPageViewController" bundle:nil andPageUrl:newUrl];

        [webpageViewController setupCartButtonOnRight];
        [webpageViewController setupNavigationInnerWithBackButton];
        [self.navigationController pushViewController:webpageViewController animated:YES];
        
        return NO;
    }else if (navigationType == UIWebViewNavigationTypeFormSubmitted) {

        if ([[[request.URL absoluteString] lowercaseString] rangeOfString:@"cart/couponpost"].location != NSNotFound) {
            [[NSNotificationCenter defaultCenter] postNotificationName:OCShowLoad object:nil];
            return YES;
        }else if ([[[request.URL absoluteString] lowercaseString] rangeOfString:@"contacts/index/post"].location != NSNotFound) {
            [[NSNotificationCenter defaultCenter] postNotificationName:OCShowLoad object:nil];
            return YES;
        }else if ([[[request.URL absoluteString] lowercaseString] rangeOfString:@"customer/account/loginpost"].location != NSNotFound) {
            [[NSNotificationCenter defaultCenter] postNotificationName:OCShowLoad object:nil];
            return YES;
        }else if ([[[request.URL absoluteString] lowercaseString] rangeOfString:@"checkout/cart/updatepost"].location != NSNotFound) {
            [[NSNotificationCenter defaultCenter] postNotificationName:OCShowLoad object:nil];
            return YES;
        }
    } else {
        if ([[[request.URL absoluteString] lowercaseString] rangeOfString:@"checkout/onepage/?app=1"].location != NSNotFound) {
            return YES;
        }else if ([[[request.URL absoluteString] lowercaseString] rangeOfString:@"checkout/onepage/success"].location != NSNotFound) {
            return YES;
        }else if ([[[request.URL absoluteString] lowercaseString] rangeOfString:@"wishlist/index/cart/item"].location != NSNotFound) {
            [[NSNotificationCenter defaultCenter] postNotificationName:OCShowLoad object:nil];
            return YES;
        }else if ([[[request.URL absoluteString] lowercaseString] rangeOfString:@"checkout/onepage"].location != NSNotFound) {
            
            [self.webview stopLoading];

            NSString* urlString = [NSString stringWithFormat:@"%@?app=1", [request.URL absoluteString]];
            [self pushCartViewControllerWithStringUrl:urlString];

            return NO;
        }
    }
    return YES;
}

- (void)pushCartViewControllerWithStringUrl:(NSString *)strUrl {
    [[NSNotificationCenter defaultCenter] postNotificationName:OCGoToCart object:nil];
}

- (BOOL)samePage:(NSURL *)firstUrl andSecondUrl:(NSURL *)secondUrl {
    if ([[firstUrl relativePath] isEqualToString:[secondUrl relativePath]]) {
        return YES;
    }
    
    return NO;
}

- (NSString *)getBaseUrl:(NSURL *)url {
    NSArray* arr1 = [[url absoluteString] componentsSeparatedByString:@"/?app"];
    NSArray* arr2 = [[arr1 firstObject] componentsSeparatedByString:@"?"];

    return [arr2 firstObject];
}

- (BOOL)handleRequestUrl:(NSString *)stringUrl {

    NSString* string = [stringUrl lowercaseString];

    if ([self isString:string includesSubString:@"ecom://"]) {
        if ([self isString:string includesSubString:@"?"]) {

            NSArray* subStringsArr = [string componentsSeparatedByString:@"?"];
            for (NSString* address in subStringsArr) {
                [self handleSingleAdress:address];
            }
            return YES;
        }else{
            [self handleSingleAdress:string];
            return YES;
        }
    }
    return NO;
}

- (void)handleSingleAdress:(NSString *)address{
    if ([self isString:address includesSubString:@"connect/"]) {
        NSArray* arr = [address componentsSeparatedByString:@"connect/"];
        NSNumber* num = [NSNumber numberWithInt:[[arr lastObject] intValue]];
        [[NSNotificationCenter defaultCenter] postNotificationName:OCUserConnecttion object:num];
    }else if ([self isString:address includesSubString:@"cart/"]) {
        NSArray* arr = [address componentsSeparatedByString:@"cart/"];
        NSNumberFormatter * f = [[NSNumberFormatter alloc] init];
        [f setNumberStyle:NSNumberFormatterDecimalStyle];
        NSNumber * num = [f numberFromString:[arr lastObject]];

        [[NSNotificationCenter defaultCenter] postNotificationName:OCCartUpdated object:num];
    }else if ([self isString:address includesSubString:@"pagefinishedloading"]) {
        [self fadeIn];
    
    }else if ([self isString:address includesSubString:@"addtocartclick"]) {
        [[NSNotificationCenter defaultCenter] postNotificationName:OCShowLoad object:nil];
    
    }else if ([self isString:address includesSubString:@"frombutton/"]) {
        
        UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"" message:@"המוצר התווסף לסל בהצלחה." delegate:self cancelButtonTitle:@"המשך בקניות" otherButtonTitles:@"לתשלום", nil];
        [alert show];
        
        NSArray* arr = [address componentsSeparatedByString:@"frombutton/"];
        NSNumberFormatter * f = [[NSNumberFormatter alloc] init];
        [f setNumberStyle:NSNumberFormatterDecimalStyle];
        NSNumber * num = [f numberFromString:[arr lastObject]];
        [[NSNotificationCenter defaultCenter] postNotificationName:OCHideLoad object:nil];

        [[NSNotificationCenter defaultCenter] postNotificationName:OCCartUpdated object:num];
    }
}

#pragma mark - UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 0) {
        
    }else{
        [self performSelector:@selector(showCart) withObject:nil afterDelay:0.6];
    }
}

- (void)showCart {
    [[NSNotificationCenter defaultCenter] postNotificationName:OCGoToCart object:nil];

}

- (BOOL)isString:(NSString *)string includesSubString:(NSString *)subString {
    return ([[string lowercaseString] rangeOfString:subString].location != NSNotFound);
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {

    NSCachedURLResponse *cachedResp = [[NSURLCache sharedURLCache] cachedResponseForRequest:webView.request];
    NSHTTPURLResponse *resp = (NSHTTPURLResponse *)cachedResp.response;
    
    NSLog(@"resp.allHeaderFields: %@", resp.allHeaderFields);
    NSLog(@"HTTP Response headers:\n%@", [resp allHeaderFields]);

    
    
    NSLog(@"webViewDidFinishLoad: %@", webView.request);
    if (self.DoNotCheckRedirects) {
        [self fadeIn];
    }
    
    if (self.updateLaunchCounter) {
        [[OCLauncherCounterManager sharedInstance] decreaseCounter];
    }
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
//    NSLog(@"didFailLoadWithError: %@", error);
    [[NSNotificationCenter defaultCenter] postNotificationName:OCHideLoad object:nil];
    if (self.updateLaunchCounter) {
        [[OCLauncherCounterManager sharedInstance] decreaseCounter];
    }
}



- (void)reloadWebview {
    if (!self.webview.isLoading) {
        [self.webview reload];
    }
}




@end
